package com.findtargettests;


import org.objectweb.asm.Handle;
import org.objectweb.asm.Label;
import org.objectweb.asm.MethodVisitor;
import org.objectweb.asm.Opcodes;
import org.objectweb.asm.Type;


import java.util.regex.Pattern;
import java.util.regex.Matcher;
import java.lang.Runnable;
import java.util.List;
import java.util.ArrayList;


public class MyMethodVisitor extends MethodVisitor {

	private boolean found;
	private List<Runnable> code;

	private final static String oraclePattern;
	private final static Pattern pattern;


	static{	         
		oraclePattern = ".*oracle.*";
		pattern = Pattern.compile(oraclePattern, Pattern.CASE_INSENSITIVE | Pattern.DOTALL);

	}
	
	public MyMethodVisitor(int api, MethodVisitor mv, int access, String name, String desc, String signature, String className, String[] exceptions) {
		super(api, mv);
		code = new ArrayList<Runnable>();
		found = false;
	}

// @Override
// 	public void visitLdcInsn(Object cst) {
// 		if(cst instanceof String){
// 			String temp = (String) cst;
// 			if(pattern.matcher(temp).matches()&&!found){
//  				super.visitMethodInsn(Opcodes.INVOKESTATIC, "com/findtargettests/Profiler", "isTargetMethod", "()V", false);
// 				System.out.println(cst);found=true;
// 							}
// 		}
// 		super.visitLdcInsn(cst);
// 	}

	@Override
	public void visitCode() {
		super.visitCode();
	}

	@Override
	public void visitEnd() {
		if(found){
			super.visitMethodInsn(Opcodes.INVOKESTATIC, "com/findtargettests/Profiler", "isTargetMethod", "()V", false);
		}
		while(!code.isEmpty()){
			code.remove(0).run();
		}
		super.visitEnd();
	}

	@Override
	public void visitParameter(String name, int access) {
		String tempName = new String(name);
		code.add(()->super.visitParameter(tempName, access));

	}

	@Override
	public void visitVarInsn(int opcode, int var) {
		code.add(() -> super.visitVarInsn(opcode, var));
	}

	@Override
	public void visitMaxs(int maxStack, int maxLocals){
		code.add(() -> super.visitMaxs(maxStack, maxLocals));
	}

	// Label instruction not counted as an instruction 
	@Override
	public void visitLabel(Label label) {
		code.add(() -> super.visitLabel(label));
	}


	@Override 
	public void visitMethodInsn(int opcode, String owner, String name, String desc, boolean itf){    
		code.add(() -> super.visitMethodInsn(opcode, owner, name, desc, itf));
	}


	@Override
	public void visitInvokeDynamicInsn(String name, String desc, Handle bsm, Object... bsmArgs){
		code.add(() -> super.visitInvokeDynamicInsn(name, desc, bsm, bsmArgs));
	}

	@Override
	public void visitJumpInsn(int opcode, Label label){
		code.add(() -> super.visitJumpInsn(opcode, label));
	}

	@Override
	public void visitLocalVariable(String name, String desc, String signature, Label start, Label end, int index){
		code.add(() -> super.visitLocalVariable(name, desc, signature, start, end, index));
	}

	@Override
	public void visitFieldInsn(int opcode, String owner, String name, String desc){   
		code.add(() -> super.visitFieldInsn(opcode, owner, name, desc));
	}

	@Override
	public void visitInsn(int opcode) {
		code.add(() -> 	super.visitInsn(opcode));
	}

	// Frame not counted as an instruction 
	@Override
	public void visitFrame(int type, int nLocal, Object[] local, int nStack, Object[] stack) {
		Object [] tempLocals;
		Object [] tempStack;
		if(local == null){
			tempLocals = null;
		}else{
			tempLocals = new Object[local.length];
			for(int i = 0; i < local.length; i++){
				tempLocals[i] = local[i]; 
			}
		} 

		if(stack == null){
			tempStack = null;
		}else{
			tempStack = new Object[stack.length];
			for(int i = 0; i < stack.length; i++){
				tempStack[i] = stack[i]; 
			}
		} 
		code.add(() -> super.visitFrame(type, nLocal, tempLocals, nStack, tempStack));
	}

	@Override
	public void visitIincInsn(int var, int increment) {
		code.add(() -> super.visitIincInsn(var, increment));
	}

	@Override
	public void visitLdcInsn(Object cst) {
		if(cst instanceof String){
			String temp = (String) cst;
			if(pattern.matcher(temp).matches()){
				found = true;
			}
		}
		code.add(() -> super.visitLdcInsn(cst));
	}

	@Override
	public void visitIntInsn(int opcode, int operand) {
		code.add(() -> super.visitIntInsn(opcode, operand));
	}

	// Line instruction not counted as an instruction
	@Override
	public void visitLineNumber(int line, Label start) {
		code.add(() -> super.visitLineNumber(line, start));
	}

	@Override
	public void visitLookupSwitchInsn(Label dflt, int[] keys, Label[] labels) {
		code.add(() -> super.visitLookupSwitchInsn(dflt, keys, labels));
	}

	@Override
	public void visitMultiANewArrayInsn(String desc, int dims) {
		code.add(() -> super.visitMultiANewArrayInsn(desc, dims));
	}

	@Override
	public void visitTableSwitchInsn(int min, int max, Label dflt, Label... labels) {
		code.add(() -> super.visitTableSwitchInsn(min, max, dflt, labels));
	}

	@Override
	public void visitTryCatchBlock(Label start, Label end, Label handler, String type) {
		code.add(() -> super.visitTryCatchBlock(start, end, handler, type));
	}

	@Override
	public void visitTypeInsn(int opcode, String type) {
		code.add(() -> super.visitTypeInsn(opcode, type));
	}

	private final void push(final int value) {
		//System.out.println(value);
	    if(value >= -1 && value <= 5) {
	        super.visitInsn(Opcodes.ICONST_0 + value);
	    } else if(value == (byte)value) {
	        super.visitIntInsn(Opcodes.BIPUSH, value);
	    } else if(value == (short)value) {
	        super.visitIntInsn(Opcodes.SIPUSH, value);
	    } else {
	        super.visitLdcInsn(value);
	    }
	}
}
