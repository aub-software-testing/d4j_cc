package com.findtargettests;

import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.HashSet;
import java.util.Set;
import java.io.BufferedWriter;
import java.io.PrintWriter;


public class Profiler{

	private static FileWriter fw;
	private static Set<String> tests;
	private static String runIdentifier;

	static{
		runIdentifier = null;
		tests = new HashSet<String>();
		// try{
		// 	fw = new FileWriter("/home/marwan/Desktop/TargetTestProfiler/profile/tests.txt", true);
		// }catch(Exception e){
		// 	e.printStackTrace(System.out);
		// 	throw new RuntimeException();
		// }
	}

	
	public static void isTargetMethod(){
		if(runIdentifier != null){
			try{
				if(tests.add(runIdentifier)){
					new FileWriter("/home/WIN2K/mki06/Desktop/TargetTestProfiler/profile/" + runIdentifier);
				}
			}catch(Exception e){
				e.printStackTrace(System.out);
				throw new RuntimeException();
			}

			// try(PrintWriter out = new PrintWriter(new BufferedWriter(fw), true)) {
			// 	if(tests.add(runIdentifier)) {
			// 		//new FileWriter("/home/marwan/Desktop/TargetTestProfiler/profile/" + runIdentifier);
			// 		out.print(runIdentifier + '\n');
			// 		out.flush();
			// 	}
			// }catch (Exception e){
			// 	e.printStackTrace(System.out);
			// 	throw new RuntimeException();
			// }
		}else{
			System.out.println("error: oracle not called by instrumented test");
		}
	}

	public static void beforeTest(String testIdentifier){
		if(runIdentifier != null){
		  	return;
		}
		runIdentifier = testIdentifier;
	}

	public static void afterTest(){	
		runIdentifier = null;
	}
}
